---
layout: default
title: code-style
---

# Code style

This page will describe the style used in the source code of cvui.

```cpp
// cv::Mat frame, x, y, label
if (cvui::button(frame, 100, 40, "Button")) {
    // button was clicked
}
```
