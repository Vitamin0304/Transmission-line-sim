cd package

# Upload the thing. Use "--repository-url https://test.pypi.org/legacy/"
# for testing, when needed.
twine upload dist/*
