/*
This is application uses the mouse API to dynamically create a ROI
for image visualization.

Copyright (c) 2017 Fernando Bevilacqua <dovyski@gmail.com>
Licensed under the MIT license.
*/

#ifndef _CLASS2_H_
#define _CLASS2_H_

class Class2 {
public:
	Class2();
	void renderMessage(cv::Mat& frame);
};

#endif // _CLASS2_H_
